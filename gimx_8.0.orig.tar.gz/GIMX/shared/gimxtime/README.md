# gimxtime

Compilation:

```
git clone https://github.com/matlo/gimxtime.git
CPPFLAGS="-I../" make -C gimxtime
```
