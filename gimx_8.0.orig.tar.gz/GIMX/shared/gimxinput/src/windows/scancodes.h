/*
 Copyright (c) 2011 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#ifndef _SCANCODES_H
#define _SCANCODES_H

unsigned char get_keycode(unsigned short flags, unsigned short scancode);

#endif /* _SCANCODES_H */
