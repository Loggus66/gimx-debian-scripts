# gimxinput

Compilation:
```
git clone https://github.com/matlo/gimxcommon.git
git clone https://github.com/matlo/gimxlog.git
CPPFLAGS="-I../" make -C gimxlog
git clone https://github.com/matlo/gimxtime.git
CPPFLAGS="-I../" make -C gimxtime
git clone https://github.com/matlo/gimxpoll.git
CPPFLAGS="-I../" make -C gimxpoll
git clone https://github.com/matlo/gimxhid.git
CPPFLAGS="-I../" make -C gimxhid
git clone https://github.com/matlo/gimxinput.git
CPPFLAGS="-I../" make -C gimxinput
```
