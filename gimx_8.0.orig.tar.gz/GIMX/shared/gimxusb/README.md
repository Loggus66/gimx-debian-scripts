# gimxusb

Compilation:

```
git clone https://github.com/matlo/gimxpoll.git
git clone https://github.com/matlo/gimxcommon.git
git clone https://github.com/matlo/gimxlog.git
CPPFLAGS="-I../" make -C gimxlog
git clone https://github.com/matlo/gimxtime.git
CPPFLAGS="-I../" make -C gimxtime
git clone https://github.com/matlo/gimxtimer.git
CPPFLAGS="-I../" make -C gimxtimer
git clone https://github.com/matlo/gimxusb.git
CPPFLAGS="-I../" make -C gimxusb
```
