/*
 Copyright (c) 2017 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#include "XmlWritter.h"
#include <string>
#include <string.h>

#include <gimxfile/include/gfile.h>

#include <gimxcontroller/include/controller.h>

using namespace std;

XmlWritter::XmlWritter()
{
    //ctor
    m_ConfigurationFile = NULL;
    m_CurrentController = 0;
    m_CurrentProfile = 0;
}

XmlWritter::XmlWritter(ConfigurationFile* configFile)
{
    //ctor
    m_ConfigurationFile = configFile;
    m_CurrentController = 0;
    m_CurrentProfile = 0;
}

XmlWritter::~XmlWritter()
{
    //dtor
}

void XmlWritter::CreateEventNode(xmlNodePtr parent_node, Event* event)
{
    xmlNodePtr e_node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_EVENT, NULL);
    xmlNewProp(e_node, BAD_CAST X_ATTR_TYPE, BAD_CAST (const char*) event->GetType().c_str());
    xmlNewProp(e_node, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) event->GetId().c_str());
    if(!strcmp((const char*) parent_node->name, X_NODE_CORRECTION))
    {
      return;
    }
    if(event->GetType().find("axis") != string::npos)
    {
        if(strcmp((const char*) parent_node->name, X_NODE_AXIS))
        {
            xmlNewProp(e_node, BAD_CAST X_ATTR_THRESHOLD, BAD_CAST (const char*) event->GetThreshold().c_str());
        }
        else
        {
            xmlNewProp(e_node, BAD_CAST X_ATTR_DEADZONE, BAD_CAST (const char*) event->GetDeadZone().c_str());
            xmlNewProp(e_node, BAD_CAST X_ATTR_MULTIPLIER, BAD_CAST (const char*) event->GetMultiplier().c_str());
            xmlNewProp(e_node, BAD_CAST X_ATTR_EXPONENT, BAD_CAST (const char*) event->GetExponent().c_str());
            xmlNewProp(e_node, BAD_CAST X_ATTR_SHAPE, BAD_CAST (const char*) event->GetShape().c_str());
        }
    }
}

void XmlWritter::CreateDeviceNode(xmlNodePtr parent_node, Device* device)
{
    xmlNodePtr d_node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_DEVICE, NULL);
    xmlNewProp(d_node, BAD_CAST X_ATTR_TYPE, BAD_CAST (const char*) device->GetType().c_str());
    xmlNewProp(d_node, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) device->GetId().c_str());
    xmlNewProp(d_node, BAD_CAST X_ATTR_NAME, BAD_CAST (const char*) device->GetName().c_str());
}

void XmlWritter::CreateAxisMapNode(xmlNodePtr parent_node)
{
    xmlNodePtr am_node;

    xmlNodePtr node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_AXIS_MAP, NULL);
    list<ControlMapper>* am_list = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetAxisMapperList();

    for(list<ControlMapper>::iterator it = am_list->begin(); it!=am_list->end(); ++it)
    {
        am_node = xmlNewChild(node, NULL, BAD_CAST X_NODE_AXIS, NULL);

        xmlNewProp(am_node, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) it->GetGenericAxisName().c_str());
		    xmlNewProp(am_node, BAD_CAST X_ATTR_LABEL, BAD_CAST (const char*) it->GetLabel().c_str());

        CreateDeviceNode(am_node, it->GetDevice());

        CreateEventNode(am_node, it->GetEvent());
    }
}

void XmlWritter::CreateButtonMapNode(xmlNodePtr parent_node)
{
    xmlNodePtr bm_node;

    xmlNodePtr node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_BUTTON_MAP, NULL);
    list<ControlMapper>* bm_list = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetButtonMapperList();

    for(list<ControlMapper>::iterator it = bm_list->begin(); it!=bm_list->end(); ++it)
    {
        bm_node = xmlNewChild(node, NULL, BAD_CAST X_NODE_BUTTON, NULL);

        xmlNewProp(bm_node, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) it->GetGenericAxisName().c_str());
		    xmlNewProp(bm_node, BAD_CAST X_ATTR_LABEL, BAD_CAST (const char*) it->GetLabel().c_str());

        CreateDeviceNode(bm_node, it->GetDevice());

        CreateEventNode(bm_node, it->GetEvent());
    }
}

void XmlWritter::CreateTriggerNode(xmlNodePtr parent_node)
{
    Trigger* trigger = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetTrigger();

    xmlNodePtr node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_TRIGGER, NULL);

    xmlNewProp(node, BAD_CAST X_ATTR_TYPE, BAD_CAST (const char*) trigger->GetDevice()->GetType().c_str());

    xmlNewProp(node, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) trigger->GetDevice()->GetId().c_str());

    xmlNewProp(node, BAD_CAST X_ATTR_NAME, BAD_CAST (const char*) trigger->GetDevice()->GetName().c_str());

    xmlNewProp(node, BAD_CAST X_ATTR_BUTTON_ID, BAD_CAST (const char*) trigger->GetEvent()->GetId().c_str());

    xmlNewProp(node, BAD_CAST X_ATTR_SWITCH_BACK, BAD_CAST (const char*) trigger->GetSwitchBack().c_str());

    xmlNewProp(node, BAD_CAST X_ATTR_DELAY, BAD_CAST (const char*) trigger->GetDelay().c_str());
}

void XmlWritter::CreateMouseOptionsNodes(xmlNodePtr parent_node)
{
    xmlNodePtr pnode = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_MOUSEOPTIONS_LIST, NULL);

    list<MouseOptions>* i_list = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetMouseOptionsList();

    for(list<MouseOptions>::iterator it = i_list->begin(); it!=i_list->end(); ++it)
    {
      xmlNodePtr nodemo = xmlNewChild(pnode, NULL, BAD_CAST X_NODE_MOUSE, NULL);

      xmlNewProp(nodemo, BAD_CAST X_ATTR_NAME, BAD_CAST (const char*) it->GetMouse()->GetName().c_str());
      xmlNewProp(nodemo, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) it->GetMouse()->GetId().c_str());

      xmlNewProp(nodemo, BAD_CAST X_ATTR_MODE, BAD_CAST (const char*) it->GetMode().c_str());

      xmlNewProp(nodemo, BAD_CAST X_ATTR_BUFFERSIZE, BAD_CAST (const char*) it->GetBufferSize().c_str());
      xmlNewProp(nodemo, BAD_CAST X_ATTR_FILTER, BAD_CAST (const char*) it->GetFilter().c_str());
    }
}

void XmlWritter::CreateJoystickCorrectionsNodes(xmlNodePtr parent_node)
{
    xmlNodePtr corrections = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_JOYSTICK_CORRECTIONS_LIST, NULL);

    list<JoystickCorrection>* i_list = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetJoystickCorrectionsList();

    for(list<JoystickCorrection>::iterator it = i_list->begin(); it!=i_list->end(); ++it)
    {
      xmlNodePtr correction = xmlNewChild(corrections, NULL, BAD_CAST X_NODE_CORRECTION, NULL);

      xmlNewProp(correction, BAD_CAST X_ATTR_LOW_VALUE, BAD_CAST (const char*) it->GetLowValue().c_str());
      xmlNewProp(correction, BAD_CAST X_ATTR_LOW_COEF, BAD_CAST (const char*) it->GetLowCoef().c_str());

      xmlNewProp(correction, BAD_CAST X_ATTR_HIGH_VALUE, BAD_CAST (const char*) it->GetHighValue().c_str());
      xmlNewProp(correction, BAD_CAST X_ATTR_HIGH_COEF, BAD_CAST (const char*) it->GetHighCoef().c_str());

      CreateDeviceNode(correction, it->GetJoystick());
      CreateEventNode(correction, it->GetAxis());
    }
}

void XmlWritter::CreateInversionNode(xmlNodePtr parent_node, ForceFeedback* ffb)
{
    xmlNodePtr d_node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_INVERSION, NULL);
    const char * value = ffb->getInversion().empty() ? "no" : ffb->getInversion().c_str();
    xmlNewProp(d_node, BAD_CAST X_ATTR_ENABLE, BAD_CAST value);
}

void XmlWritter::CreateGainNode(xmlNodePtr parent_node, ForceFeedback* ffb)
{
    xmlNodePtr d_node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_GAIN, NULL);
    xmlNewProp(d_node, BAD_CAST X_ATTR_RUMBLE, BAD_CAST ffb->getRumbleGain().c_str());
    xmlNewProp(d_node, BAD_CAST X_ATTR_CONSTANT, BAD_CAST ffb->getConstantGain().c_str());
    xmlNewProp(d_node, BAD_CAST X_ATTR_SPRING, BAD_CAST ffb->getSpringGain().c_str());
    xmlNewProp(d_node, BAD_CAST X_ATTR_DAMPER, BAD_CAST ffb->getDamperGain().c_str());
}

void XmlWritter::CreateForceFeedbackNode(xmlNodePtr parent_node)
{
    ForceFeedback * tweaks = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetForceFeedback();

    if (!tweaks->GetJoystick()->GetName().empty())
    {
        xmlNodePtr node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_FORCE_FEEDBACK, NULL);
        CreateDeviceNode(node, tweaks->GetJoystick());
        CreateInversionNode(node, tweaks);
        CreateGainNode(node, tweaks);
    }
}

void XmlWritter::CreateMacrosNode(xmlNodePtr parent_node)
{
    const std::string& macros = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->getMacros();

    if (!macros.empty())
    {
        xmlNodePtr node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_MACROS, NULL);
        xmlNodeAddContent(node, BAD_CAST macros.c_str());
    }
}

void XmlWritter::CreateIntensityNodes(xmlNodePtr parent_node)
{
    xmlNodePtr pnode = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_INTENSITY_LIST, NULL);

    list<Intensity>* i_list = m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->GetIntensityList();

    for(list<Intensity>::iterator it = i_list->begin(); it!=i_list->end(); ++it)
    {
      if(it->GetDirection() != "Increase" && it->GetDirection() != "Decrease")
      {
        continue;
      }
      
      xmlNodePtr node = xmlNewChild(pnode, NULL, BAD_CAST X_NODE_INTENSITY, NULL);

      xmlNewProp(node, BAD_CAST X_ATTR_CONTROL, BAD_CAST (const char*) it->GetGenericAxisName().c_str());

      xmlNewProp(node, BAD_CAST X_ATTR_DEADZONE, BAD_CAST (const char*) it->GetDeadZone().c_str());

      xmlNewProp(node, BAD_CAST X_ATTR_SHAPE, BAD_CAST (const char*) it->GetShape().c_str());

      xmlNewProp(node, BAD_CAST X_ATTR_STEPS, BAD_CAST (const char*) it->GetSteps().c_str());

      xmlNodePtr nodedir = NULL;
      
      if(it->GetDirection() == "Increase")
      {
        nodedir = xmlNewChild(node, NULL, BAD_CAST X_NODE_UP, NULL);
      }
      else if(it->GetDirection() == "Decrease")
      {
        nodedir = xmlNewChild(node, NULL, BAD_CAST X_NODE_DOWN, NULL);
      }

      xmlNewProp(nodedir, BAD_CAST X_ATTR_TYPE, BAD_CAST (const char*) it->GetDevice()->GetType().c_str());

      xmlNewProp(nodedir, BAD_CAST X_ATTR_NAME, BAD_CAST (const char*) it->GetDevice()->GetName().c_str());

      xmlNewProp(nodedir, BAD_CAST X_ATTR_ID, BAD_CAST (const char*) it->GetDevice()->GetId().c_str());

      xmlNewProp(nodedir, BAD_CAST X_ATTR_BUTTON_ID, BAD_CAST (const char*) it->GetEvent()->GetId().c_str());
    }
}

void XmlWritter::CreateConfigurationNodes(xmlNodePtr parent_node)
{
    xmlNodePtr node;
    char id[2];
    int i;
        
    for(i=0; i<MAX_PROFILES; ++i)
    {
        m_CurrentProfile = i;
        
        if(m_ConfigurationFile->GetController(m_CurrentController)->GetProfile(m_CurrentProfile)->IsEmpty())
        {
          continue;
        }

        node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_CONFIGURATION, NULL);

#ifndef WIN32
        snprintf(id, sizeof(id), "%hhu", i+1);
#else
        snprintf(id, sizeof(id), "%hu", i+1);
#endif

        xmlNewProp(node, BAD_CAST X_ATTR_ID, BAD_CAST id);

        CreateTriggerNode(node);

        CreateMouseOptionsNodes(node);

        CreateIntensityNodes(node);

        CreateButtonMapNode(node);

        CreateAxisMapNode(node);

        CreateJoystickCorrectionsNodes(node);

        CreateForceFeedbackNode(node);

        CreateMacrosNode(node);
    }
}

void XmlWritter::CreateControllerNodes(xmlNodePtr parent_node)
{
    xmlNodePtr node;
    char id[2];
    char dpi[16];
    int i;

    for(i=0; i<MAX_CONTROLLERS; ++i)
    {
        m_CurrentController = i;
        
        if(m_ConfigurationFile->GetController(m_CurrentController)->IsEmpty())
        {
          continue;
        }

        node = xmlNewChild(parent_node, NULL, BAD_CAST X_NODE_CONTROLLER, NULL);

#ifndef WIN32
        snprintf(id, sizeof(id), "%hhu", i+1);
#else
        snprintf(id, sizeof(id), "%hu", i+1);
#endif

        xmlNewProp(node, BAD_CAST X_ATTR_ID, BAD_CAST id);

        snprintf(dpi, sizeof(dpi), "%u", m_ConfigurationFile->GetController(m_CurrentController)->GetMouseDPI());

        xmlNewProp(node, BAD_CAST X_ATTR_DPI, BAD_CAST dpi);

        const char* cname = controller_get_name(m_ConfigurationFile->GetController(m_CurrentController)->GetControllerType());

        xmlNewProp(node, BAD_CAST X_ATTR_TYPE, BAD_CAST cname);

        CreateConfigurationNodes(node);
    }
}

xmlDocPtr XmlWritter::ToDoc()
{
    LIBXML_TEST_VERSION;

    xmlDocPtr doc = xmlNewDoc(BAD_CAST "1.0");
    xmlNodePtr root_node = xmlNewNode(NULL, BAD_CAST X_NODE_ROOT);
    xmlDocSetRootElement(doc, root_node);

    CreateControllerNodes(root_node);

    return doc;
}

int XmlWritter::WriteConfigFile(const string& directory, const string& file)
{
    int ret;
    xmlDocPtr doc = ToDoc();

    string path = directory + "/" + file;
    ret = xmlSaveFormatFileEnc(path.c_str(), doc, "UTF-8", 1);

#ifndef WIN32
    if(ret != -1 && gfile_makeown(path.c_str()) < 0)
    {
      ret = -1;
    }
#endif

    xmlFreeDoc(doc);

    return ret;
}

int XmlWritter::ToString(string& config)
{
    int ret = 0;
    xmlDocPtr doc = ToDoc();

    xmlChar *s;
    int size;
    xmlDocDumpFormatMemoryEnc(doc, &s, &size, "UTF-8", 1);
    if (s != NULL) {
        config = (char *)s;
        xmlFree(s);
    } else {
        ret = -1;
    }

    xmlFreeDoc(doc);

    return ret;
}
