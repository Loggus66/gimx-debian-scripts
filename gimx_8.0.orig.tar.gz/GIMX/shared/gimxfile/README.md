# gimxfile

Compilation:
```
git clone https://github.com/matlo/gimxcommon.git
git clone https://github.com/matlo/gimxfile.git
CPPFLAGS="-I../" make -C gimxfile
```
