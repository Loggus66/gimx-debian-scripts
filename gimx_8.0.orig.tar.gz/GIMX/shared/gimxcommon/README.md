# gimxcommon

This repository contains source code that is common to the GIMX librairies.  
The code is compiled by each library using it. It is not meant to be compiled separately.
