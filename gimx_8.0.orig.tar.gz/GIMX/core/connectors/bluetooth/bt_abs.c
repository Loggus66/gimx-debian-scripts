/*
 Copyright (c) 2015 Mathieu Laurendeau <mat.lau@laposte.net>
   License: GPLv3
*/

#include <connectors/bluetooth/bt_abs.h>

e_bt_abs bt_abs_value = DEFAULT_BT_ABS;
