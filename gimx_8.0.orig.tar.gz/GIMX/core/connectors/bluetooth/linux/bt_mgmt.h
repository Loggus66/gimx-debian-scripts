/*
 Copyright (c) 2014 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#ifndef BT_MGMT_H
#define BT_MGMT_H
 
#include <stdint.h>

int bt_mgmt_adapter_init(uint16_t index);

#endif
