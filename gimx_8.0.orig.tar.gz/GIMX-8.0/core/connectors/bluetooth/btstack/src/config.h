// config.h created by configure for BTstack  Mon Dec 1 14:21:54 CET 2014
#define HAVE_TRANSPORT_USB
#define USB_PRODUCT_ID 0x0001
#define USB_VENDOR_ID 0x0A12
#define USE_POSIX_RUN_LOOP
#define HAVE_SDP
#define HAVE_RFCOMM
#define REMOTE_DEVICE_DB remote_device_db_memory
#define HAVE_TIME
#define ENABLE_LOG_INFO 
#define ENABLE_LOG_ERROR
#define HCI_ACL_PAYLOAD_SIZE 1021
